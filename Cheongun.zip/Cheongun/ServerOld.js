const express = require('express');
const fs = require('fs');
const https = require('https');
const http = require('http');
const path = require('path');

// Express와 기본 미들웨어 설정
const app = express();
const httpPort = 8080; // HTTP 서버 포트
const httpsPort = 4430; // HTTPS 서버 포트
const safe = true; // HTTPS를 사용할지 여부를 결정하는 변수

app.use(express.json()); // Express에 내장된 JSON 파서 사용
app.use(express.static('public')); // HTML 파일을 제공할 폴더

// SSL 인증서와 개인 키 파일 경로
const certsDir = path.join(__dirname, 'certs');
const privateKeyPath = path.join(certsDir, 'private.key');
const certificatePath = path.join(certsDir, 'certificate.crt');
const caPath = path.join(certsDir, 'ca_bundle.crt');

// SSL 인증서와 개인 키 파일을 읽습니다. safe가 true일 경우에만 사용됩니다.
const credentials = safe ? {
    key: fs.readFileSync(privateKeyPath, 'utf8'),
    cert: fs.readFileSync(certificatePath, 'utf8'),
    ca: fs.readFileSync(caPath, 'utf8')
} : null;

// 시간표 저장
app.post('/api/record', (req, res) => {
    const record = req.body;

    fs.readFile('timetable.json', (err, data) => {
        if (err) {
            if (err.code === 'ENOENT') {
                // 파일이 없을 경우 빈 배열로 초기화
                fs.writeFile('timetable.json', JSON.stringify([record], null, 2), (err) => {
                    if (err) {
                        console.error('Error writing timetable.json:', err);
                        return res.status(500).send('Internal Server Error');
                    }
                    res.sendStatus(200);
                });
            } else {
                console.error('Error reading timetable.json:', err);
                return res.status(500).send('Internal Server Error');
            }
        } else {
            let timetable = JSON.parse(data);
            timetable.push(record);

            fs.writeFile('timetable.json', JSON.stringify(timetable, null, 2), (err) => {
                if (err) {
                    console.error('Error writing timetable.json:', err);
                    return res.status(500).send('Internal Server Error');
                }
                res.sendStatus(200);
            });
        }
    });
});

// 시간표 가져오기
app.get('/api/timetable', (req, res) => {
    fs.readFile('timetable.json', (err, data) => {
        if (err) {
            console.error('Error reading timetable.json:', err);
            return res.status(500).send('Internal Server Error');
        }

        res.json(JSON.parse(data));
    });
});

// 상태 업데이트
app.post('/api/update-status', (req, res) => {
    const updatedRecord = req.body;

    fs.readFile('timetable.json', (err, data) => {
        if (err) {
            console.error('Error reading timetable.json:', err);
            return res.status(500).send('Internal Server Error');
        }

        let timetable = JSON.parse(data);
        timetable = timetable.map(entry => {
            if (entry.busNumber === updatedRecord.busNumber &&
                entry.route === updatedRecord.route &&
                entry.startTime === updatedRecord.startTime &&
                entry.endTime === updatedRecord.endTime) {
                entry.status = updatedRecord.status;
            }
            return entry;
        });

        fs.writeFile('timetable.json', JSON.stringify(timetable, null, 2), (err) => {
            if (err) {
                console.error('Error writing timetable.json:', err);
                return res.status(500).send('Internal Server Error');
            }
            res.sendStatus(200);
        });
    });
});

// HTTP 서버 생성 및 시작
const httpServer = http.createServer(app);
httpServer.listen(httpPort, () => {
    console.log(`HTTP Server is running on http://localhost:${httpPort}`);
}).on('error', (err) => {
    console.error('HTTP server error:', err);
});

// HTTPS 서버 생성 및 시작
if (safe && credentials) {
    const httpsServer = https.createServer(credentials, app);
    httpsServer.listen(httpsPort, () => {
        console.log(`HTTPS Server is running on https://localhost:${httpsPort}`);
    }).on('error', (err) => {
        console.error('HTTPS server error:', err);
    });
}