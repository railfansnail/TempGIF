const express = require('express');
const fs = require('fs');
const https = require('https');
const http = require('http');
const path = require('path');
const { setInterval } = require('timers');

// Express와 기본 미들웨어 설정
const app = express();
const httpPort = 8080; // HTTP 서버 포트
const httpsPort = 443; // HTTPS 서버 포트
const safe = true; // HTTPS를 사용할지 여부를 결정하는 변수

app.use(express.json()); // Express에 내장된 JSON 파서 사용
app.use(express.static('public')); // HTML 파일을 제공할 폴더

// SSL 인증서와 개인 키 파일 경로
const certsDir = path.join(__dirname, 'certs');
const privateKeyPath = path.join(certsDir, 'private.key');
const certificatePath = path.join(certsDir, 'certificate.crt');
const caPath = path.join(certsDir, 'ca_bundle.crt');

// SSL 인증서와 개인 키 파일을 읽습니다. safe가 true일 경우에만 사용됩니다.
let credentials = null;
if (safe) {
    try {
        credentials = {
            key: fs.readFileSync(privateKeyPath, 'utf8'),
            cert: fs.readFileSync(certificatePath, 'utf8'),
            ca: fs.readFileSync(caPath, 'utf8')
        };
    } catch (err) {
        console.error('Error loading SSL certificates:', err);
        process.exit(1); // 인증서 문제로 서버를 종료합니다.
    }
}

// 파일 경로
const timetableFilePath = 'timetable.json';
const backupFilePath = 'timetable_backup.json';

// 시간표 저장
app.post('/api/record', (req, res) => {
    const record = req.body;

    fs.readFile(timetableFilePath, (err, data) => {
        if (err) {
            if (err.code === 'ENOENT') {
                // 파일이 없을 경우 빈 배열로 초기화
                fs.writeFile(timetableFilePath, JSON.stringify([record], null, 2), (err) => {
                    if (err) {
                        console.error('Error writing timetable.json:', err);
                        return res.status(500).send('Internal Server Error');
                    }
                    res.sendStatus(200);
                });
            } else {
                console.error('Error reading timetable.json:', err);
                return res.status(500).send('Internal Server Error');
            }
        } else {
            try {
                let timetable = JSON.parse(data);
                timetable.push(record);

                fs.writeFile(timetableFilePath, JSON.stringify(timetable, null, 2), (err) => {
                    if (err) {
                        console.error('Error writing timetable.json:', err);
                        return res.status(500).send('Internal Server Error');
                    }
                    res.sendStatus(200);
                });
            } catch (parseError) {
                console.error('Error parsing timetable.json:', parseError);
                return res.status(500).send('Internal Server Error');
            }
        }
    });
});

// 시간표 가져오기
app.get('/api/timetable', (req, res) => {
    fs.readFile(timetableFilePath, (err, data) => {
        if (err) {
            console.error('Error reading timetable.json:', err);
            return res.status(500).send('Internal Server Error');
        }

        try {
            const timetable = JSON.parse(data);
            res.json(timetable);
        } catch (parseError) {
            console.error('Error parsing timetable.json:', parseError);
            return res.status(500).send('Internal Server Error');
        }
    });
});

// 상태 업데이트
app.post('/api/update-status', (req, res) => {
    const updatedRecord = req.body;

    fs.readFile(timetableFilePath, (err, data) => {
        if (err) {
            console.error('Error reading timetable.json:', err);
            return res.status(500).send('Internal Server Error');
        }

        try {
            let timetable = JSON.parse(data);
            timetable = timetable.map(entry => {
                if (entry.busNumber === updatedRecord.busNumber &&
                    entry.route === updatedRecord.route &&
                    entry.startTime === updatedRecord.startTime &&
                    entry.endTime === updatedRecord.endTime) {
                    entry.status = updatedRecord.status;
                }
                return entry;
            });

            fs.writeFile(timetableFilePath, JSON.stringify(timetable, null, 2), (err) => {
                if (err) {
                    console.error('Error writing timetable.json:', err);
                    return res.status(500).send('Internal Server Error');
                }
                res.sendStatus(200);
            });
        } catch (parseError) {
            console.error('Error parsing timetable.json:', parseError);
            return res.status(500).send('Internal Server Error');
        }
    });
});

// JSON 유효성 검사 함수
function validateJson(filePath) {
    try {
        const data = fs.readFileSync(filePath, 'utf8');
        JSON.parse(data); // 파싱 시 오류가 발생하면 예외 발생
        return true;
    } catch (e) {
        console.error('Invalid JSON format:', e.message);
        return false;
    }
}

// 백업 함수
function backupFile() {
    fs.copyFile(timetableFilePath, backupFilePath, (err) => {
        if (err) {
            console.error('Error creating backup:', err);
        } else {
            console.log('Backup created successfully.');
        }
    });
}

// 유효성 검사 및 오류 발생 시 백업 복원
function validateAndRestore() {
    if (!validateJson(timetableFilePath)) {
        console.error('Restoring from backup due to JSON validation error.');
        fs.copyFile(backupFilePath, timetableFilePath, (err) => {
            if (err) {
                console.error('Error restoring backup:', err);
            } else {
                console.log('Backup restored successfully.');
            }
        });
    }
}

// 유효성 검사 결과를 콘솔에 출력
function logValidationResult() {
    const isValid = validateJson(timetableFilePath);
    console.log(`JSON validation result: ${isValid ? 'Valid' : 'Invalid'}`);
}

// 백업 및 유효성 검사 작업 설정
let backupInProgress = false;
let validationInProgress = false;

// 백업 작업
setInterval(() => {
    if (!backupInProgress && !validationInProgress) {
        backupInProgress = true;
        backupFile();
        backupInProgress = false;
    }
}, 10000); // 10초마다 백업

// 유효성 검사 작업
setInterval(() => {
    if (!validationInProgress && !backupInProgress) {
        validationInProgress = true;
        logValidationResult();
        validateAndRestore();
        validationInProgress = false;
    }
}, 1000); // 1초마다 유효성 검사

// HTTP 서버 생성 및 시작
let httpServer = null;
if (!safe) {
    httpServer = http.createServer(app);
    httpServer.listen(httpPort, () => {
        console.log(`HTTP Server is running on http://localhost:${httpPort}`);
    }).on('error', (err) => {
        console.error('HTTP server error:', err);
    });
}

// HTTPS 서버 생성 및 시작
if (safe && credentials) {
    const httpsServer = https.createServer(credentials, app);
    httpsServer.listen(httpsPort, () => {
        console.log(`HTTPS Server is running on https://localhost:${httpsPort}`);
        // HTTPS 서버가 실행되면 HTTP 서버를 종료합니다.
        if (httpServer) {
            httpServer.close(() => {
                console.log('HTTP Server has been stopped.');
            });
        }
    }).on('error', (err) => {
        console.error('HTTPS server error:', err);
    });
}

// 종료 상태 자동 업데이트 함수
function updateEndTimeStatus() {
    fs.readFile(timetableFilePath, (err, data) => {
        if (err) {
            console.error('Error reading timetable.json:', err);
            return;
        }

        try {
            let timetable = JSON.parse(data);
            const now = new Date();

            timetable = timetable.map(entry => {
                const endTime = new Date(entry.endTime);
                if (now > endTime && entry.status !== '종료') {
                    entry.status = '종료';
                }
                return entry;
            });

            fs.writeFile(timetableFilePath, JSON.stringify(timetable, null, 2), (err) => {
                if (err) {
                    console.error('Error updating timetable.json:', err);
                } else {
                    console.log('End times updated successfully.');
                }
            });
        } catch (parseError) {
            console.error('Error parsing timetable.json:', parseError);
        }
    });
}

// 종료 상태 자동 업데이트 작업 설정
setInterval(updateEndTimeStatus, 60000); // 60초마다 종료 상태 업데이트
